const messageToDisplay = "Just a message"

document.write(messageToDisplay)